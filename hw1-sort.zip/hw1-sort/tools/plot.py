"""비교 결과를 그래프(SVG)로 그린다.

    make charts          # 또는
    python3 tools/plot.py

src/main.out --csv / --pivots 를 돌려 측정값을 받아 report/ 아래에 SVG를 쓴다.
사람이 읽는 표를 파싱하지 않고 CSV를 쓰는 이유는, 표의 모양이 바뀌어도
그래프가 깨지지 않게 하려는 것이다.

표준 모듈만 쓴다. 그림은 tools/svgchart.py가 직접 찍어 낸다.
"""

import csv
import io
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import svgchart  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
BINARY = ROOT / "src" / "main.out"
OUT_DIR = ROOT / "report"
ALGOS = ["mergeSort", "quickSort", "heapSort"]
PIVOTS = ["last", "middle", "median3"]
KIND_KEYS = ["random", "sorted", "reversed", "few-unique"]
KIND_LABEL = {
    "random": "무작위",
    "sorted": "정렬됨",
    "reversed": "역순",
    "few-unique": "중복많음",
}
INT_FIELDS = ("n", "compares", "moves", "extraBytes", "maxDepth", "sorted", "stable")


def run_csv(flag):
    """측정 프로그램을 돌려 CSV를 읽는다. 없으면 make가 만들게 한다."""
    if not BINARY.exists():
        subprocess.run(["make", "src/main.out"], cwd=ROOT, check=True)
    result = subprocess.run([str(BINARY), flag], cwd=ROOT, check=True,
                            capture_output=True, text=True)
    rows = list(csv.DictReader(io.StringIO(result.stdout)))
    for row in rows:
        for key in INT_FIELDS:
            if key in row:
                row[key] = int(row[key])
        row["millis"] = float(row["millis"])
    return rows


def save_csv(rows, name):
    """그래프와 보고서의 표가 같은 실행에서 나오도록 측정값을 그대로 남긴다."""
    with open(OUT_DIR / name, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def pick(rows, **conditions):
    return [r for r in rows if all(r[k] == v for k, v in conditions.items())]


def by_series(rows, names, name_field, field, keys, key_field):
    """{계열 이름: [키 순서대로의 값]} 으로 모은다."""
    table = {}
    for name in names:
        values = []
        for key in keys:
            match = [r for r in rows if r[name_field] == name and r[key_field] == key]
            values.append(match[0][field] if match else 0)
        table[name] = values
    return table


def by_algo(rows, field, keys, key_field):
    return by_series(rows, ALGOS, "algo", field, keys, key_field)


def main():
    OUT_DIR.mkdir(exist_ok=True)
    rows = run_csv("--csv")
    save_csv(rows, "results.csv")
    kinds = pick(rows, scope="kinds")
    growth = pick(rows, scope="growth")
    shape_labels = [KIND_LABEL[k] for k in KIND_KEYS]
    made = []

    # 1. 입력 형태별 실행 시간 · 비교 횟수 (n = 4,000). 퀵 정렬 값이 커서 로그 축을 쓴다
    for field, unit, stem, label, fmt in (
            ("millis", "시간 (ms, 로그)", "input-time", "입력 형태별 실행 시간 (n=4000)", svgchart.ms),
            ("compares", "비교 횟수 (로그)", "input-compares", "입력 형태별 비교 횟수 (n=4000)", svgchart.si)):
        made.append(svgchart.grouped_bar_chart(
            OUT_DIR / f"{stem}.svg", label, None, shape_labels,
            by_algo(kinds, field, KIND_KEYS, "input"), unit,
            log_scale=True, value_label=fmt))

    # 2. 무작위 입력에서 n에 따른 실행 시간
    sizes = sorted({r["n"] for r in growth})
    made.append(svgchart.line_chart(
        OUT_DIR / "growth-time.svg", "n에 따른 실행 시간 (무작위 입력)", None,
        sizes, by_algo(growth, "millis", sizes, "n"), "n", "시간 (ms)",
        log_axes=False, annotate_slope=False))

    # 3. 피벗 선택 방법별 퀵 정렬 비교 횟수
    pivots = run_csv("--pivots")
    save_csv(pivots, "pivots.csv")
    made.append(svgchart.grouped_bar_chart(
        OUT_DIR / "pivot-compares.svg", "피벗 선택 방법별 퀵 정렬 비교 횟수 (n=4000)", None,
        shape_labels, by_series(pivots, PIVOTS, "pivot", "compares", KIND_KEYS, "input"),
        "비교 횟수 (로그)", log_scale=True))

    for path in made:
        print(f"wrote {Path(path).relative_to(ROOT)}")


if __name__ == "__main__":
    main()
