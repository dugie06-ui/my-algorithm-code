/* 병합 정렬 — 반으로 쪼개 각각 정렬한 뒤, 정렬된 두 반쪽을 하나로 합친다.
 *
 * 입력이 어떻든 늘 같은 모양으로 쪼개므로 시간은 언제나 O(n log n)이다.
 * 대신 합칠 때 원소를 잠시 옮겨 둘 보조 배열(n칸)이 필요하다. 셋 중에
 * 입력 크기에 비례하는 메모리를 쓰는 것은 이 정렬뿐이다.
 */
#include "sort.h"

#include <stdlib.h>

#include "sortctx.h"

/* 보조 배열 쪽 원소끼리 비교한다. 비교 횟수는 sortCompareAt과 똑같이 센다. */
static int compareRaw(SortCtx *c, const char *x, const char *y) {
    if (c->stats != NULL) {
        c->stats->compares++;
    }
    return c->cmp(x, y);
}

/* 정렬된 a[lo..mid)와 a[mid..hi)를 합친다. buf는 n칸짜리 보조 배열이다. */
static void merge(SortCtx *c, char *buf, size_t lo, size_t mid, size_t hi) {
    const size_t sz = c->size;

    /* 1. 두 반쪽을 보조 배열로 그대로 옮긴다. */
    for (size_t k = lo; k < hi; k++) {
        sortMove(c, buf + k * sz, sortElemAt(c, k));
    }
    /* 2. 양쪽 앞머리를 견주며 작은 쪽을 원래 배열에 차례로 내려놓는다. */
    size_t i = lo;  /* 왼쪽 반의 앞머리 */
    size_t j = mid; /* 오른쪽 반의 앞머리 */
    for (size_t k = lo; k < hi; k++) {
        if (i >= mid) {
            sortMove(c, sortElemAt(c, k), buf + j++ * sz);
        } else if (j >= hi) {
            sortMove(c, sortElemAt(c, k), buf + i++ * sz);
        } else if (compareRaw(c, buf + i * sz, buf + j * sz) <= 0) {
            /* '<='로 같으면 왼쪽을 먼저 낸다. 이 한 글자가 안정성을 만든다. */
            sortMove(c, sortElemAt(c, k), buf + i++ * sz);
        } else {
            sortMove(c, sortElemAt(c, k), buf + j++ * sz);
        }
    }
}

/* a[lo..hi)를 정렬한다. depth는 재귀 깊이 측정용이다. */
static void mergeSortRange(SortCtx *c, char *buf, size_t lo, size_t hi, size_t depth) {
    sortTrackDepth(c, depth);
    if (hi - lo < 2) {
        return; /* 원소 하나는 이미 정렬돼 있다 */
    }
    size_t mid = lo + (hi - lo) / 2;
    mergeSortRange(c, buf, lo, mid, depth + 1);
    mergeSortRange(c, buf, mid, hi, depth + 1);
    merge(c, buf, lo, mid, hi);
}

void mergeSort(void *base, size_t n, size_t size, SortCompare cmp, SortStats *stats) {
    SortCtx c;
    if (!sortBegin(&c, base, n, size, cmp, stats)) {
        return;
    }
    /* 보조 배열은 처음에 한 번만 잡는다. 병합마다 malloc하면 시간이 그쪽으로 샌다. */
    char *buf = (char *)malloc(n * size);
    if (buf == NULL) {
        sortEnd(&c);
        return;
    }
    sortAddExtra(&c, n * size);
    mergeSortRange(&c, buf, 0, n, 1);
    free(buf);
    sortEnd(&c);
}
