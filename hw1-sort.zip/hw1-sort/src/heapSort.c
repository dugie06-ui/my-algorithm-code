/* 힙 정렬 — 배열을 최대 힙으로 만든 뒤, 맨 위(가장 큰 값)를 끝으로 보내고
 * 남은 부분을 다시 힙으로 고치기를 되풀이한다. (수업에서 다루지 않은 정렬)
 *
 * 힙은 따로 만들지 않는다. 배열 자체를 완전 이진 트리로 읽는다:
 *   a[i]의 자식은 a[2i+1], a[2i+2], 부모는 a[(i-1)/2].
 * 그래서 추가 메모리가 교환용 한 칸뿐이고, 최악에도 O(n log n)이다.
 * 대신 트리를 멀리 건너뛰며 교환하므로 불안정하고 캐시에 불리하다.
 */
#include "sort.h"

#include "sortctx.h"

/* a[root]를 자식과 견주며 제자리로 내려보낸다(sift-down). 힙 크기는 end다.
 * 재귀 대신 반복문으로 써서 재귀 깊이는 늘 1이다. */
static void siftDown(SortCtx *c, size_t root, size_t end) {
    for (;;) {
        size_t child = 2 * root + 1; /* 왼쪽 자식 */
        if (child >= end) {
            return; /* 잎이다 */
        }
        /* 오른쪽 자식이 더 크면 그쪽을 본다. */
        if (child + 1 < end && sortCompareAt(c, child, child + 1) < 0) {
            child++;
        }
        /* 부모가 더 큰 자식보다 작지 않으면 힙 조건이 선다. */
        if (sortCompareAt(c, root, child) >= 0) {
            return;
        }
        sortSwap(c, root, child);
        root = child;
    }
}

void heapSort(void *base, size_t n, size_t size, SortCompare cmp, SortStats *stats) {
    SortCtx c;
    if (!sortBegin(&c, base, n, size, cmp, stats)) {
        return;
    }
    /* 1단계: 힙 만들기 (Floyd). 잎은 이미 힙이므로 마지막 부모부터 거꾸로 내려보낸다.
     * 원소를 하나씩 넣는 방식은 O(n log n)이지만 이쪽은 O(n)이다. */
    for (size_t i = n / 2; i-- > 0;) {
        siftDown(&c, i, n);
    }
    /* 2단계: 꺼내기. 가장 큰 a[0]을 끝으로 보내고, 힙을 한 칸 줄여 다시 고친다. */
    for (size_t end = n - 1; end > 0; end--) {
        sortSwap(&c, 0, end);
        siftDown(&c, 0, end);
    }
    sortEnd(&c);
}
