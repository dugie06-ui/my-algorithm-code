/* 퀵 정렬 — 피벗 하나를 골라 그보다 작은 것은 왼쪽, 나머지는 오른쪽으로
 * 가른 뒤(분할), 양쪽을 따로 정렬한다.
 *
 * 분할은 교재의 Lomuto 방식이다. 피벗을 잘 고르면 매번 반씩 갈라져
 * O(n log n)이고, 한쪽으로 쏠리면 O(n^2)이다. 어느 쪽이 되는지는 입력과
 * 피벗 고르는 법이 함께 정한다 — 그래서 고르는 법을 바꿔 볼 수 있게 두었다.
 *
 * 멀리 떨어진 원소끼리 교환하므로 같은 값의 순서가 섞인다 (불안정).
 */
#include "sort.h"

#include "sortctx.h"

QuickPivot quickSortPivot = PIVOT_LAST; /* 기본은 교재 그대로 */

const char *quickPivotName(QuickPivot pivot) {
    switch (pivot) {
        case PIVOT_LAST:    return "last";
        case PIVOT_MIDDLE:  return "middle";
        case PIVOT_MEDIAN3: return "median3";
        default:            return "?";
    }
}

/* 교환하되, 같은 칸이면 건너뛴다. 제자리 교환도 이동 3회로 세면 숫자가 부풀기 때문이다. */
static void swapIfDiff(SortCtx *c, size_t i, size_t j) {
    if (i != j) {
        sortSwap(c, i, j);
    }
}

/* a[lo..hi]에서 피벗을 골라 맨 끝(hi)으로 옮겨 둔다. 분할은 늘 끝의 피벗을 쓴다. */
static void choosePivot(SortCtx *c, size_t lo, size_t hi) {
    size_t mid = lo + (hi - lo) / 2;

    switch (quickSortPivot) {
        case PIVOT_MIDDLE:
            swapIfDiff(c, mid, hi);
            break;
        case PIVOT_MEDIAN3:
            /* 세 원소를 정렬해 가운데 값이 mid에 오게 한 뒤 끝으로 보낸다. */
            if (hi - lo >= 2) {
                if (sortCompareAt(c, mid, lo) < 0) swapIfDiff(c, mid, lo);
                if (sortCompareAt(c, hi, lo) < 0)  swapIfDiff(c, hi, lo);
                if (sortCompareAt(c, hi, mid) < 0) swapIfDiff(c, hi, mid);
                swapIfDiff(c, mid, hi);
            }
            break;
        case PIVOT_LAST:
        default:
            break; /* 이미 끝에 있다 */
    }
}

/* Lomuto 분할. 끝의 피벗보다 작은 원소를 앞으로 모으고, 피벗이 설 자리를 돌려준다. */
static size_t partition(SortCtx *c, size_t lo, size_t hi) {
    choosePivot(c, lo, hi);
    size_t store = lo; /* a[lo..store)는 피벗보다 작다 */
    for (size_t j = lo; j < hi; j++) {
        if (sortCompareAt(c, j, hi) < 0) {
            swapIfDiff(c, store, j);
            store++;
        }
    }
    swapIfDiff(c, store, hi); /* 피벗을 제자리에 — 이 원소는 다시 움직이지 않는다 */
    return store;
}

/* a[lo..hi]를 정렬한다 (hi 포함). */
static void quickSortRange(SortCtx *c, size_t lo, size_t hi, size_t depth) {
    sortTrackDepth(c, depth);
    if (lo >= hi) {
        return;
    }
    size_t p = partition(c, lo, hi);
    if (p > lo) {
        quickSortRange(c, lo, p - 1, depth + 1); /* size_t라 p-1이 음수가 되지 않게 */
    }
    quickSortRange(c, p + 1, hi, depth + 1);
}

void quickSort(void *base, size_t n, size_t size, SortCompare cmp, SortStats *stats) {
    SortCtx c;
    if (!sortBegin(&c, base, n, size, cmp, stats)) {
        return;
    }
    quickSortRange(&c, 0, n - 1, 1);
    sortEnd(&c);
}
